sd_nuestra <-
function(x){sqrt((sd(x)^2)*(length(x)-1)/length(x))}
