frecrel <-
function(x){table(x)/length(x)}
