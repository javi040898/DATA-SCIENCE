var_nuestra <-
function(x){sd_nuestra(x)^2}
