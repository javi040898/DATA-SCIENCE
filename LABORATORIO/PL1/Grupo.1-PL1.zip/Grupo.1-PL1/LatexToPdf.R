Sweave("Grupo.1-PL1.Rnw")
tools::texi2pdf("Grupo.1-PL1.tex")