#Parte 1
#1.1
(muestra = t(matrix(c(3,2,3.5,12,4.7,4.1,5.2,4.9,7.1,6.1,6.2,5.2,14,5.3),2,7, dimnames=list(c("r","d")))))
(muestra <-data.frame(muestra))

#DIAGRAMA DE CAJA Y BIGOTES
(boxplot(muestra$r, range=1.5, plot=TRUE))

(cuar1r<-quantile(muestra$r, 0.25))
(cuar3r<-quantile(muestra$r, 0.75))
(int =c(cuar1r-1.5*(cuar3r-cuar1r), cuar3r+1.5*(cuar3r-cuar1r))) #Intervalo en el que estan los valores normales
for (i in 1:length(muestra$r)) {
	if (muestra$r[i]<int[1] || muestra$r[i]>int[2]) {
		print("el suceso");print(i); print(muestra$r[i]); print("es un suceso anomalo o outlier")
	}
}

#1.2
(intdes=c(mean(muestra$d)-2*sd(muestra$d), mean(muestra$d)+2*sd(muestra$d))) #Con la sd de r
sdd=sqrt(var(muestra$d)*((length(muestra$d)-1)/length(muestra$d)))
(intdes =c(mean(muestra$d) -2*sdd, mean(muestra$d)+2*sdd)) #Con la sd vista en teoria

for (i in 1:length(muestra$d)){
	if (muestra$d[i]<intdes[1] || muestra$d[i]>intdes[2]) {
		print ("el suceso"); print(i); print("es un suceso anomalo o outlier")
	}
}

#1.3
(dfr =lm(muestra$d~muestra$r))
(summary(dfr))

(res=summary(dfr)$residuals)
(sr=sqrt(sum(res^2)/7))

for (i in 1:length(res)) {
	if (res[i]>2*sr){
		print("el suceso"); print(res[i]); print("es un suceso anomalo o outlier")
	}
}

#1.4po
(muestra=matrix(c(4,4,4,3,5,5,1,1,5,4),2,5))
(muestra<-t(muestra))

(distancias = as.matrix(dist(muestra)))
(distancias = matrix(distancias,5,5))

for (i in 1:5){
	(distancias[,i] = sort(distancias[,i])); 
	(distanciasordenadas = distancias)
	}
distanciasordenadas

for (i in 1:5){
	if (distanciasordenadas[4,i]>2.5) { #2.5 grado de outlier
		print(i); print("es un suceso anomalo o outlier")
	}	
}
