#Parte 2
(muestra = t(matrix(c(3,2,3.5,12,4.7,4.1,5.2,4.9,7.1,6.1,6.2,5.2,14,5.3),2,7, dimnames=list(c("r","d")))))
(muestra <-data.frame(muestra))

#Regresion
recta=lm(muestra$d~muestra$r)
distancias=cooks.distance(recta)
lim1=4*mean(distancias)
lim2=2*mean(distancias)
plot(distancias)
abline(h=lim1, col="blue")
abline(h=lim2, col="purple")

#Desviacion tipica
sdd=sqrt(var(muestra$d)*((length(muestra$d)-1)/length(muestra$d)))
(intdes =c(mean(muestra$d) -2*sdd, mean(muestra$d)+2*sdd))
plot(muestra$d)
abline(h=intdes[1], col="blue")
abline(h=intdes[2], col="blue")

#K-vecinos
install.packages("adamethods")
library("adamethods")
(muestra=matrix(c(4,4,4,3,5,5,1,1,5,4),2,5))
(muestra<-t(muestra))
do_knno(muestra, 2, 1)

####Con otro dataset####

#Regresion
(muestraI=iris)
rectaI=lm(muestraI$Sepal.Length~muestraI$Sepal.Width)
distanciasI=cooks.distance(rectaI)
(lim1I=4*mean(distanciasI))
(lim2I=2*mean(distanciasI))
plot(distanciasI)
abline(h=lim1I, col="blue")
abline(h=lim2I, col="purple")

#Desvicion tipica
sddI=sqrt(var(muestraI$Sepal.Length)*((length(muestraI$Sepal.Length)-1)/length(muestra$Sepal.Length)))
(intdesI =c(mean(muestraI$Sepal.Length) -2*sdd, mean(muestraI$Sepal.Length)+2*sdd))
plot(muestraI$Sepal.Length, ylim=c(0, 15))
abline(h=intdesI[1], col="blue")
abline(h=intdesI[2], col="blue")

#K-vecinos
do_knno(muestraI, 2, 1)

#Cajas y bigotes
(boxplot(muestraI$Sepal.Length, range=1.5, plot=TRUE))

(cuar1r<-quantile(muestraI$Sepal.Length, 0.25))
(cuar3r<-quantile(muestraI$Sepal.Length, 0.75))
(int =c(cuar1r-1.5*(cuar3r-cuar1r), cuar3r+1.5*(cuar3r-cuar1r))) #Intervalo en el que estan los valores normales
for (i in 1:length(muestraI$Sepal.Length)) {
	if (muestraI$Sepal.Length[i]<int[1] || muestraI$Sepal.Length[i]>int[2]) {
		print("el suceso");print(i); print(muestra$r[i]); print("es un suceso anomalo o outlier")
	}
}


